<template>
  <div id="botoes",>
    <button @click="adicionar()">Entrou</button>
    <button @click="remover()">Saiu</button>
    <button @click="zerar()">Zerar</button>
  </div>
</template>

<script>
export default {
  name: "Botoes",
emits: ["contMais", "contMenos", "zerar"],
methods: {
    adicionar() {
      this.contador++;
    },
    remover() {
      this.contador--;
    },
    zerar() {
      this.contador = 0;
    },
  },
};
</script>
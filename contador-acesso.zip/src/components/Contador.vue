<template>
  <div class="container">
    <p>{{ valor }}</p>
  </div>
</template>
  

<script>
export default {
  name: "Contador",
  props: {
    valor: Number,
  },
};
</script>

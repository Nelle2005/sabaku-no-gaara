<template>
  <header>
    <h1>Contador de Acesso</h1>
    <h3>Bem Vindos</h3>
    <h4>Números acessados:</h4>
  </header>
</template>

<script>
export default {
  name: "Header",
};
</script>


<style scoped>
h1 {
  text-align: center;
  font-size: 5em;
  color: #B0E0E6;
  font-family: Impact sans-serif;
}

h3 {
  text-align: center;
  font-size: 2em;
  color: #C71585;
}
h4 {
  text-align: center;
  font-size: 3em;
  color: #00FF00;
}
</style>

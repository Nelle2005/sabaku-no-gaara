<template>
  <Header />

  <Contador :valor="contador" />

  <Botoes @contMais="adicionar()" @contMenos="remover()" @zerar="zerar()" />
</template>

<script>
import Header from "./components/Header";
import Contador from "./components/Contador";
import Botoes from "./components/Botoes";

export default {
  name: "App",
  components: {
    Header,
    Contador,
    Botoes,
  },
  data() {
    return {
      contador: 0,
    };
  },
  methods: {
    adicionar() {
      this.contador++;
    },
    remover() {
      this.contador--;
    },
    zerar() {
      this.contador = 0;
    },
  },
};
</script>
